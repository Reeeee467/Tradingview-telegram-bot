
from flask import Flask, request
import telegram

app = Flask(__name__)

# Token dan Chat ID kamu
BOT_TOKEN = '7651201399:AAHTa2eob8q2mGqeHMeLGCAThN2Yp5n4zG8'
CHAT_ID = '547606202'
bot = telegram.Bot(token=BOT_TOKEN)

@app.route('/alert', methods=['POST'])
def webhook():
    data = request.json
    symbol = data.get("symbol", "Unknown")
    condition = data.get("condition", "No Condition")
    price = data.get("price", "N/A")

    message = f"📈 ALERT from TradingView!\n\n📌 Symbol: {symbol}\n📊 Condition: {condition}\n💰 Price: {price}"
    bot.send_message(chat_id=CHAT_ID, text=message)
    return 'OK', 200

if __name__ == '__main__':
    app.run()
